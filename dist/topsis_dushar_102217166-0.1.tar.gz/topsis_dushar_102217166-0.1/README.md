# Topsis-Dushar-102217166

This is a Python package to implement the Topsis (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation

You can install the package via pip:

pip install Topsis-Dushar-102217166

## Usage

After installation, you can use the `topsis` command line tool like this:

python -m topsis 102217166-data.csv "1,1,1,3,2" "+,+,-,-,+" 102217166-result.csv
